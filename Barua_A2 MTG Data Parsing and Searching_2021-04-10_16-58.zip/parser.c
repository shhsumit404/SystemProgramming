#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "card.h"

/* Define names for output files */
#define INDEX_FILENAME "index.bin"
#define CARDS_FILENAME "cards.bin"
 
const char* rarity_names[4] = {"common", "uncommon", "rare", "mythic"};

/* structure for all cards */
struct card_array
{
    struct card* items;  /* cards */
    int size;       /* actual number of cards at the array */
    int capacity;   /* allocated space at the array */
};

/* structure for card names and offset */
struct card_index
{
    char *name;         /* card name */
    long int offset;    /* card offset at the cards file */
};

/* structure for all card names and offsets */
struct card_index_array
{
    struct card_index *items;
    int size;
    int capacity;
};

/* Helper function declarations */

/* Creates deep copy of the card */
void copy_card(struct card* from, struct card* to);

/* Creates copy of the given string and returns pointer to the copy */
char* copy_str(const char* str);

/* Frees all string fields of the given card */
void clear_card(struct card* pcard);

/* Initializes array for storing 10 cards */
void initialize_card_array(struct card_array *cards);

/* Add new card into array
   If array is full, increases capacity by 10. */
void add_card_to_array(struct card_array* cards, struct card* card);

/* Removes card at given position from the array */
void remove_card_from_array(struct card_array* cards, int pos);

/* Looking for the card by name. If card with given name found, returns its index,
   or returns -1 if card with given name is not found */
int find_card_by_name(struct card_array *cards, const char* name);

/* Deletes all cards from the array, frees all allocated memory */
void clear_card_array(struct card_array *cards);


/* Reads information about one card from the given file
   and saves this information into structure card
   Returns 1 if parsing succeed, 0 otherwise */
int parse_card(FILE* fp, struct card* pcard);

/* Reads one string field from the source file pointed by fp
   and saves string into buffer pointed by str.
   Eliminates start and end quotes.
   Returns 1 if reading succeed, 0 otherwise */
int parse_string_field(FILE* fp, char* str);

/* Allocates memory for all strings at the card to given maximum size */
void initialize_card(struct card* pcard, int str_size);

/* Function for comparing indexes by name field */
int compare_indexes (const struct card_index* index1, const struct card_index* index2);

/* Function writes string into given binary file in format <length><chars without ending\0>  */
void write_string(FILE* fp, const char* str);

/* Function writes card fields into given binary file except name field */
void write_card_binary(FILE* fp, const struct card* pcard);

/* Function creates index and card binary files */
void create_index_card_files(const struct card_array* cards, FILE* fpindex, FILE* fpcards);

/* Function creates index array and card binary file */
void create_index(const struct card_array* cards, FILE* fpcards, struct card_index_array* indexes);

/* Initializes array for storing 10 card indexes */
void initialize_index_array(struct card_index_array *cards);

/* Deletes all cards from the array, frees all allocated memory */
void clear_index_array(struct card_index_array* cards);

/* Add new card into array
   If array is full, increases capacity by 10. */
void add_index_to_array(struct card_index_array* cards, struct card_index* index);

/* Function saves index array into index binary file */
void save_index_file(const struct card_index_array* indexes, FILE* fpindex);

int main(int argc, char* argv[])
{
    FILE* fp;
    FILE* fpindex;
    FILE* fpcards;
    struct card_array cards;
    struct card_index_array indexes;
    struct card card_buffer;
    int position;

    /* validate that file-name provided */
    if (argc < 2) {
        fprintf(stderr, "Usage: parser <file name>\n");
        return 1;
    }

    /* try to open source file */
    fp = fopen(argv[1], "r");
    if (!fp) {
        fprintf(stderr, "./parser: cannot open(\"%s\"): No such file or directory\n", argv[1]);
        return 1;
    }

    /* Open index file */
    fpindex = fopen(INDEX_FILENAME, "wb");
    if (!fpindex) {
        fprintf(stderr, "Can't open index file %s for writing!\n", INDEX_FILENAME);
        fclose(fp);
        return 1;
    }

    /* Open cards file */
    fpcards = fopen(CARDS_FILENAME, "wb");
    if (!fpcards) {
        fprintf(stderr, "Can't open cards file %s for writing!\n", CARDS_FILENAME);
        fclose(fp);
        fclose(fpindex);
        return 1;
    }

    /* initialize card array */
    initialize_card_array(&cards);

    /* initialize card buffer */
    initialize_card(&card_buffer, 1024);

    /* skip the first line from the source file */
    /* while (!feof(fp) && fgetc(fp) != '\n') {} */
    fscanf(fp, "%*[^\n]\n");

    /* read all cards and copy information into array */
    while (parse_card(fp, &card_buffer)) {

        /* search for card with given name at the array */
        position = find_card_by_name(&cards, card_buffer.name);
        if (position == -1) {
            /* name not found - add new card */
            add_card_to_array(&cards, &card_buffer);
        }
        else if (card_buffer.id > cards.items[position].id) {
            /* if name found and new card has the bigger id - remove the old card at position */
            remove_card_from_array(&cards, position);
            add_card_to_array(&cards, &card_buffer);
        }
    }

    /* close source file */
    fclose(fp);

    /* Create index array and cards.bin file */
    create_index(&cards, fpcards, &indexes);

    /* close resulting cards file */
    fclose(fpcards);

    /* Sort index array by qsort */
    qsort(indexes.items, indexes.size, sizeof (struct card_index), (int(*) (const void *, const void *)) compare_indexes);

    /* save information into binary files */
    save_index_file(&indexes, fpindex);

    /* close resulting index file */
    fclose(fpindex);

    /* Clear all allocated memory */
    clear_card(&card_buffer);
    clear_card_array(&cards);
    clear_index_array(&indexes);

    return 0;
}


void initialize_card_array(struct card_array *cards)
{
    if (cards == NULL) {
        return ;
    }

    cards->items = (struct card*) malloc (sizeof(struct card) * 10);
    cards->size = 0;
    cards->capacity = 10;
}

void copy_card(struct card* from, struct card* to)
{
    if (from == NULL || to == NULL) {
        return;
    }

    to->id = from->id;
    to->name = copy_str(from->name);
    to->cost = copy_str(from->cost);
    to->converted_cost = from->converted_cost;
    to->type = copy_str(from->type);
    to->text = copy_str(from->text);
    to->stats = copy_str(from->stats);
    to->rarity = from->rarity;
}

/* Creates copy of the given string and returns pointer to the copy */
char* copy_str(const char* str)
{
    int size;
    char* new_str;

    if (str == NULL) {
        return NULL;
    }

    /* allocate memory for copy string */
    size = strlen(str);

    /* copy all characters including the last \0 */
    new_str = (char*) malloc (sizeof(char) * (size + 1));
    memcpy(new_str, str, size + 1);

    /* return pointer to the string copy */
    return new_str;
}

/* Frees all string fields of the given card */
void clear_card(struct card* pcard)
{
    if (pcard == NULL) {
        return;
    }
    free(pcard->name);
    free(pcard->cost);
    free(pcard->type);
    free(pcard->text);
    free(pcard->stats);
}


/* Add new card into array
   If array is full, increases capacity by 10. */
void add_card_to_array(struct card_array* cards, struct card* pcard)
{
    if (cards == NULL || pcard == NULL) {
        return;
    }

    struct card* old_items;

    /* If array is full */
    if (cards->size == cards->capacity) {
        /* increase array capacity by 10 */
        old_items = cards->items;
        cards->capacity += 10;
        cards->items = (struct card*) malloc (sizeof(struct card) * cards->capacity);
        memcpy(cards->items, old_items, sizeof(struct card) * cards->size);
        free(old_items);
    }

    /* Copy new card at the end of the array */
    copy_card(pcard, &(cards->items[cards->size]));
    cards->size++;
}

/* Removes card at given position from the array */
void remove_card_from_array(struct card_array* pcards, int pos)
{
    int i;

    if (pcards == NULL || pos < 0 || pos >= pcards->size) {
        return;
    }

    /* free memory by the card at position pos */
    clear_card(&pcards->items[pos]);

    /* shift all ascending cards */
    for (i = pos; i < pcards->size - 1; i++)
    {
      pcards->items[i].id = pcards->items[i + 1].id;
      pcards->items[i].name = pcards->items[i + 1].name;
      pcards->items[i].cost = pcards->items[i + 1].cost;
      pcards->items[i].converted_cost = pcards->items[i + 1].converted_cost;
      pcards->items[i].type = pcards->items[i + 1].type;
      pcards->items[i].text = pcards->items[i + 1].text;
      pcards->items[i].stats = pcards->items[i + 1].stats;
      pcards->items[i].rarity = pcards->items[i + 1].rarity;
    }
    pcards->size--;
}

/* Allocates memory for all strings at the card to given maximum size */
void initialize_card(struct card* pcard, int str_size)
{
    if (pcard == NULL) {
        return ;
    }

    pcard->id = 0;
    pcard->rarity = common;
    pcard->converted_cost = 0;
    pcard->name = (char*) malloc (str_size);
    pcard->cost = (char*) malloc (str_size);
    pcard->type = (char*) malloc (str_size);
    pcard->text = (char*) malloc (str_size);
    pcard->stats = (char*) malloc (str_size);
}

/* Reads information about one card from the given file
   and saves this information into structure card
   Returns 1 if parsing succeed, 0 otherwise */
int parse_card(FILE* fp, struct card* pcard)
{
    int i;
    char rarity_str[20];

    if (fp == NULL || feof(fp) || pcard == NULL) {
        return 0;
    }

    /* try to read id */
    if (fscanf(fp, "%ud", &(pcard->id)) != 1) {
        return 0; /* can't read integer id */
    }

    /* skip one ',' */
    if (fgetc(fp) != ',') {
        return 0;
    }

    /* parse name field */
    if (!parse_string_field(fp, pcard->name)) {
        return 0;
    }

    /* parse cost field */
    if (!parse_string_field(fp, pcard->cost)) {
        return 0;
    }

    /* try to read converted_cost */
    if (fscanf(fp, "%ud", &(pcard->converted_cost)) != 1) {
        return 0; /* can't read integer converted_cost */
    }

    /* skip one ',' */
    if (fgetc(fp) != ',') {
        return 0;
    }

    /* parse type field */
    if (!parse_string_field(fp, pcard->type)) {
        return 0;
    }

    /* parse text field */
    if (!parse_string_field(fp, pcard->text)) {
        return 0;
    }

    /* parse stats field */
    if (!parse_string_field(fp, pcard->stats)) {
        return 0;
    }

    /* parse rarity field */
    if (!parse_string_field(fp, rarity_str)) {
        return 0;
    }

    for (i = 0; i < 4; i++) {
        if (strcmp(rarity_names[i], rarity_str) == 0) {
            pcard->rarity = i;
            return 1;
        }
    }

    return 0; /* unknown rarity */
}

/* Reads one string field from the source file pointed by fp
   and saves string into buffer pointed by str.
   Eliminates start and end quotes.
   Returns 1 if parsing succeed, 0 otherwise */
int parse_string_field(FILE* fp, char* str)
{
    int c;
    int str_size = 0;
    int end_quote_found = 0;

    if (fp == NULL || str == NULL) {
        return 0;
    }

    str[0] = '\0';

    c = fgetc(fp);

    if (c == ',') {
        return 1; /* empty field */
    }

    /* skip leading '"' */
    if (c != '"') {
        return 0;
    }

    /* Read all characters until ending '"'  found */
    end_quote_found = 0;
    while (!end_quote_found && (c = fgetc(fp))) {
        /* analyze "\n" sequence */
        if (c == '\\') {
            c = fgetc(fp);
            if (c == 'n') {
                /* \n sequence - copy 1 character '\n' */
                c = '\n';
                str[str_size] = '\n';
                str_size++;
                str[str_size] = '\0';
            }
            else {
                /* not \n sequence - copy 2 characters */
                str[str_size] = '\\';
                str[str_size + 1] = c;
                str_size += 2;
                str[str_size] = '\0';
            }

        }
        else if (c == '"')
        {
            /* analyze "" sequence */
            c = fgetc(fp);
            if (c == '"') {
                /* "" sequence - copy only one character " */
                str[str_size] = '"';
                str_size++;
                str[str_size] = '\0';
            }
            else {
                /* ending " found - do not copy it into output string */
                end_quote_found = 1;
            }
        }
        else
        {
            /* copy character into str */
            str[str_size] = c;
            str_size++;
            str[str_size] = '\0';
        }
    }

    return 1;
}

/* Looking for the card by name. If card with given name found, returns its index,
   or returns -1 if card with given name is not found */
int find_card_by_name(struct card_array *cards, const char* name)
{
    int i;

    if (cards == NULL || name == NULL) {
        return -1;
    }

    for (i = 0; i < cards->size; i++) {
        if (strcmp(cards->items[i].name, name) == 0) {
            return i;
        }
    }

    return -1; /* given name not found */
}

/* Deletes all cards from the array, frees all allocated memory */
void clear_card_array(struct card_array* cards)
{
    int i;

    if (cards == NULL) {
        return ;
    }

    for (i = 0; i < cards->size; i++) {
        clear_card(&(cards->items[i]));
    }

    free(cards->items);
    cards->items = NULL;
    cards->capacity = 0;
    cards->size = 0;
}

/* Function for comparing indexes by name field */
int compare_indexes (const struct card_index* index1, const struct card_index* index2)
{
    return strcmp(index1->name, index2->name);
}

/* Function writes string into given binary file in format <length><chars without ending\0>  */
void write_string(FILE* fp, const char* str)
{
    uint32_t strSize;

    if (fp == NULL || str == NULL) {
        return ;
    }

    /* write string length */
    strSize = strlen(str);
    fwrite(&strSize, sizeof(strSize), 1, fp);
    fwrite(str, sizeof(char), strSize, fp);
}

/* Function creates index and card binary files */
void create_index_card_files(const struct card_array* cards, FILE* fpindex, FILE* fpcards){
    int i;
    long int offset;

    if (cards == NULL || fpindex == NULL || fpcards == NULL) {
        return ;
    }

    for (i = 0; i < cards->size; i++) {
        /* write name into index file */
        write_string(fpindex, cards->items[i].name);
        offset = ftell(fpcards);
        /* write card offset into index file */
        fwrite(&offset, sizeof(offset), 1, fpindex);

        /* write card fields except name into cards file */
        write_card_binary(fpcards, &cards->items[i]);
    }
}

/* Function writes card fields into given binary file except name field */
void write_card_binary(FILE* fp, const struct card* pcard)
{
    /* write card fields except name into cards file */
    fwrite(&(pcard->id), sizeof(pcard->id), 1, fp);
    write_string(fp, pcard->cost);
    fwrite(&(pcard->converted_cost), sizeof(pcard->converted_cost), 1, fp);
    write_string(fp, pcard->type);
    write_string(fp, pcard->text);
    write_string(fp, pcard->stats);
    fwrite(&(pcard->rarity), sizeof(pcard->rarity), 1, fp);
}

/* Initializes array for storing 10 card indexes */
void initialize_index_array(struct card_index_array *cards)
{
    if (cards == NULL) {
        return ;
    }

    cards->items = (struct card_index*) malloc (sizeof(struct card_index) * 10);
    cards->size = 0;
    cards->capacity = 10;
}

/* Deletes all cards from the array, frees all allocated memory */
void clear_index_array(struct card_index_array* cards)
{
    int i;

    if (cards == NULL) {
        return ;
    }

    for (i = 0; i < cards->size; i++) {
        free(cards->items[i].name);
    }
    free(cards->items);
    cards->items = NULL;
    cards->capacity = 0;
    cards->size = 0;
}

/* Add new card into array
   If array is full, increases capacity by 10. */
void add_index_to_array(struct card_index_array* cards, struct card_index* index)
{
    if (cards == NULL || index == NULL) {
        return;
    }

    struct card_index* old_items;

    /* If array is full */
    if (cards->size == cards->capacity) {
        /* increase array capacity by 10 */
        old_items = cards->items;
        cards->capacity += 10;
        cards->items = (struct card_index*) malloc (sizeof(struct card_index) * cards->capacity);
        memcpy(cards->items, old_items, sizeof(struct card_index) * cards->size);
        free(old_items);
    }

    /* Copy new index at the end of the array */
    cards->items[cards->size].name = copy_str(index->name);
    cards->items[cards->size].offset = index->offset;
    cards->size++;
}

/* Function creates index array and card binary file */
void create_index(const struct card_array* pcards, FILE* fpcards, struct card_index_array* pindexes)
{
    int i;
    struct card_index index_buff;

    if (pcards == NULL || pindexes == NULL || fpcards == NULL) {
        return ;
    }

    index_buff.name = (char*) malloc (50);

    initialize_index_array(pindexes);

    for (i = 0; i < pcards->size; i++) {
        /* create index for given card */
        strcpy(index_buff.name, pcards->items[i].name);
        index_buff.offset = ftell(fpcards);

        /* save card index at array */
        add_index_to_array(pindexes, &index_buff);

        /* write card fields except name into cards file */
        write_card_binary(fpcards, &pcards->items[i]);
    }

    free(index_buff.name);
}

/* Function saves index array into index binary file */
void save_index_file(const struct card_index_array* indexes, FILE* fpindex)
{
    int i;

    if (indexes == NULL || fpindex == NULL) {
        return ;
    }

    for (i = 0; i < indexes->size; i++) {
        /* write name into index file */
        write_string(fpindex, indexes->items[i].name);
        /* write card offset into index file */
        fwrite(&indexes->items[i].offset, sizeof(indexes->items[i].offset), 1, fpindex);
    }
}
