#ifndef RECIPE_H
#define RECIPE_H

#define MAX_RECIPE_COUNT 1024
#define MAX_PREREQS_COUNT 64
#define MAX_CMDS_COUNT 128

// typedef struct Command {
//    const char* name; /* command name */
//    const char** args;
//    const char* in; /* input */
//    const char* out; /* output */
//    struct Command* next;
// } Command;

typedef struct Recipe {
    const char* targetName;
    const char* prereqs[MAX_PREREQS_COUNT];
    int prereqCount;
    //Command* commands;
    const char* commands[MAX_CMDS_COUNT];
    int cmdCount;
    int upToDate;
    struct Recipe* next;
} Recipe;

#endif