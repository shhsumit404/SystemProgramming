#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

/* Definition for 'nftw' function */
/* Source: https://pubs.opengroup.org/onlinepubs/9699919799/functions/nftw.html */
#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED
#include <ftw.h>
#include "list.h"
#include "utilities.h"
/*
The nftw function is part of the POSIX-compliant set.
to provide the required multithreading for the program */

/* Constant for 'nftw' function */
/* The argument fd_limit sets the
maximum number of file descriptors
that shall be used by nftw() while traversing the file tree */
#define NFTW_FD_LIMIT 15

/* Number of fragments reader threads */
#define FILE_READER_THREAD_COUNT 8

/* Global variables */
pthread_cond_t  cv_Empty;
pthread_mutex_t mutex_FileNamesListGuard;
pthread_mutex_t mutex_FragmentsSortedListGuard;

struct MP3FragmentNode* list_FilesInSourceDirectory;
struct MP3FragmentNode* list_SortedFragmentsData;
int Flag_AllFilesEnumerated = 0;

/*
   one thread (the "Mp3FragmentsEnumThreadFunc" and "NftwCallbackFunc" functions) calls the "nftw" file
   enumeration function and puts the full paths of the found files into the "list_FilesInSourceDirectory"
   list
*/
/* Mp3-file fragments reader thread function */
void* Mp3FragmentsReaderThreadFunc(void* arg)
{
    /* Suppress "Unused parameter" */
    (void) arg;

    struct MP3FragmentData* data;

    while(1)
    {
        pthread_mutex_lock(&mutex_FileNamesListGuard);
        {
            /* Wait on condition variable while buffer is empty and Flag_AllFilesEnumerated flag is not set */
            while(ListIsEmpty(list_FilesInSourceDirectory) && !Flag_AllFilesEnumerated)
            {
                /* Wait for signal buffer EMPTY-status changed */
                pthread_cond_wait(&cv_Empty, &mutex_FileNamesListGuard);
            }

            /* If all files handled - exit loop */
            if(ListIsEmpty(list_FilesInSourceDirectory) && Flag_AllFilesEnumerated)
            {
                pthread_mutex_unlock(&mutex_FileNamesListGuard);

                break;
            }

            /* Get list's front node */
            data = ListPopFront(&list_FilesInSourceDirectory);

                if(data == NULL)
                {
                    fprintf(stderr, "Pop file path from list failed\n");
                    exit(1);
                }
        }
        pthread_mutex_unlock(&mutex_FileNamesListGuard);

        /* Broadcast signal of buffer EMPTY-status changed */
        pthread_cond_broadcast(&cv_Empty);

        /* Get from file name and set file ID - number of mp3 piece */
        data->id = GetFileId(data->filePathName);

        if(data->id == -1)
        {
            /* Unexpected file or some error - free data block */
            ListFreeData(&data);
        }
        else
        {
            /* Get file size */
            data->fileSize = GetFileSize(data->filePathName);

                if(data->fileSize == 0)
                {
                    fprintf(stderr, "Get file '%s' size failed\n", data->filePathName);
                    exit(1);
                }

            /* Read file content */
            data->fileData = GetFileData(data->filePathName, data->fileSize);

                if(data->fileData == NULL)
                {
                    fprintf(stderr, "Get file '%s' content failed\n", data->filePathName);
                    exit(1);
                }

            /* Add mp3-fragment data to sorted list */
            pthread_mutex_lock(&mutex_FragmentsSortedListGuard);
            {
                ListInsertOrdered(&list_SortedFragmentsData, data);
            }
            pthread_mutex_unlock(&mutex_FragmentsSortedListGuard);
        }
    }

    return NULL;
}


/* Callback function for Nftw-file enumerator */
static int NftwCallbackFunc(const char* fpath, const struct stat* sb, int tflag, struct FTW* ftwbuf)
{
    /* Suppress "Unused parameter" */
    (void) sb;
    (void) tflag;
    (void) ftwbuf;

    /* Handle file elements only */
    if(tflag == FTW_F)
    {
        pthread_mutex_lock(&mutex_FileNamesListGuard);
        {
            /* Insert file path and name to list */
            int result;
            result = ListInsertToFront(&list_FilesInSourceDirectory, fpath);

                if(result == ERROR_RESULT)
                {
                    fprintf(stderr, "Insert file path to list failed\n");
                    exit(1);
                }

            /* Set signal of buffer EMPTY-status changed */
            pthread_cond_signal(&cv_Empty);
        }
        pthread_mutex_unlock(&mutex_FileNamesListGuard);
    }

    return 0;
}

/* File enumerator thread function */
void* Mp3FragmentsEnumThreadFunc(void* arg)
{
    int result;
    char* sourceDirectory;
    sourceDirectory = (char*) arg;

    /* Enumerate all files in source directory */
    result = nftw(sourceDirectory, NftwCallbackFunc, NFTW_FD_LIMIT, 0);

        if(result < 0)
        {
            fprintf(stderr, "nftw failed\n");
            exit(1);
        }

    /* Broadcast signal of buffer EMPTY-status changed and all files enumerated */
    pthread_mutex_lock(&mutex_FileNamesListGuard);
    {
        Flag_AllFilesEnumerated = 1;
    }
    pthread_mutex_unlock(&mutex_FileNamesListGuard);

    pthread_cond_broadcast(&cv_Empty);

    return NULL;
}


int main(int argc, char* argv[])
{
    int i;
    int result;
    char* sourceDirectory;
    char* resultFile;
    pthread_t allThreads[1 + FILE_READER_THREAD_COUNT];

    if(argc < 3)
    {
        printf("Usage: ./defrag <DirectoryPath> <OutputFile>\n");
        return 1;
    }

    sourceDirectory = argv[1];
    resultFile = argv[2];

    /* Init lists for mp3-fragments */
    ListInit(&list_FilesInSourceDirectory);
    ListInit(&list_SortedFragmentsData);

    /* Init pthread-objects */
    pthread_mutex_init(&mutex_FileNamesListGuard, NULL);
    pthread_mutex_init(&mutex_FragmentsSortedListGuard, NULL);
    pthread_cond_init (&cv_Empty, NULL);

    /* Start consumer threads */
    if(pthread_create(&allThreads[0], NULL, Mp3FragmentsEnumThreadFunc, sourceDirectory))
    {
        fprintf(stderr, "Creating producer thread failed\n");
        return 1;
    }

    /* Start producer threads */
    for(i = 1; i <= FILE_READER_THREAD_COUNT; ++i)
    {
        if(pthread_create(&allThreads[i], NULL, Mp3FragmentsReaderThreadFunc, NULL))
        {
            fprintf(stderr, "Creating consumer thread failed\n");
            return 1;
        }
    }

    /* Wait for work consumer threads completion */
    for(i = 0; i < (1 + FILE_READER_THREAD_COUNT); ++i)
    {
        if(pthread_join(allThreads[i], NULL))
        {
            fprintf(stderr, "Error joining thread\n");
            return 1;
        }
    }

    /* Write result file */
    /* t this time, the head thread of the program waits for all worker threads to finish and then calls
          the "WriteMp3FragmentsToFile" function to write the resulting file and clean up resources */
    result = WriteMp3FragmentsToFile(&list_SortedFragmentsData, resultFile);

        if(result == ERROR_RESULT)
        {
            fprintf(stderr, "WriteMp3FragmentsToFile failed\n");
            exit(1);
        }

    /* Free lists */
    ListFree(&list_FilesInSourceDirectory);
    ListFree(&list_SortedFragmentsData);

    /* Destroy mutex and condition variables */
    pthread_mutex_destroy(&mutex_FileNamesListGuard);
    pthread_mutex_destroy(&mutex_FragmentsSortedListGuard);
    pthread_cond_destroy(&cv_Empty);

    return 0;
}
