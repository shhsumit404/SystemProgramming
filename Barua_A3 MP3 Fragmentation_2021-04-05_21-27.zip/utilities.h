#ifndef MP3_FRAGMENTS_UTILITIES_HEADER_
#define MP3_FRAGMENTS_UTILITIES_HEADER_

#include "list.h"

size_t GetFileSize(char* filePathName);

unsigned char* GetFileData(char* filePathName, size_t fileSize);

int GetFileId(char* filePathName);

int WriteMp3FragmentsToFile(struct MP3FragmentNode** list, const char* resultFileName);

#endif /* MP3_FRAGMENTS_UTILITIES_HEADER_ */
