#ifndef MP3_FRAGMENTS_LINKED_LIST_HEADER_
#define MP3_FRAGMENTS_LINKED_LIST_HEADER_

#define SUCCESS_RESULT      0
#define ERROR_RESULT        1

struct MP3FragmentData
{
    char* filePathName;
    int id;
    size_t fileSize;
    unsigned char* fileData;
};

struct MP3FragmentNode
{
    struct MP3FragmentData* data;
    struct MP3FragmentNode* next;
};

void ListInit(struct MP3FragmentNode** head);

int ListIsEmpty(struct MP3FragmentNode* head);

int ListInsertToFront(struct MP3FragmentNode** head, const char* filePathName);

int ListInsertToFront2(struct MP3FragmentNode** head, struct MP3FragmentData* data);

struct MP3FragmentData* ListPopFront(struct MP3FragmentNode** head);

int ListInsertOrdered(struct MP3FragmentNode** head, struct MP3FragmentData* data);

void ListFree(struct MP3FragmentNode** head);

void ListFreeData(struct MP3FragmentData** data);

#endif /* MP3_FRAGMENTS_LINKED_LIST_HEADER_ */
