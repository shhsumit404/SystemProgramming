#ifndef COMMAND_H
#define COMMAND_H

#define MAX_ARGS_COUNT 256

typedef struct Command {
    char* args[MAX_ARGS_COUNT];
    char* input;
    char* output;
} Command;

#endif