/*the file "utilities.c" contains functions used to work with a singly linked list */
/* the files "utilities.c" and "utilities.h" contain auxiliary functions for getting
   the fragment number from the file name, getting the file size and reading its contents into the buffer,
   as well as a function for writing the fragments sorted in order to the resulting file. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include "utilities.h"

size_t GetFileSize(char* filePathName)
{
    struct stat st;
    int result;
    result = stat(filePathName, &st);
    return result == 0 ? (size_t) st.st_size : 0;
}

unsigned char* GetFileData(char* filePathName, size_t fileSize)
{
    FILE* file;
    unsigned char* buffer;
    size_t result;

    buffer = (unsigned char*) malloc((unsigned long) fileSize * sizeof(unsigned char));

    if(buffer == NULL)
    {
        return NULL;
    }

    file = fopen(filePathName,"rb");

    if(file == NULL)
    {
        free(buffer);
        return NULL;
    }

    result = fread(buffer, 1, fileSize, file);

    if(result != fileSize)
    {
        free(file);
        return NULL;
    }

    fclose(file);

    return buffer;
}

int GetFileId(char* filePathName)
{
    size_t len = strlen(filePathName);

    /* Total length of path must be bigger extension */
    if(len < sizeof(".mp3"))
    {
        return -1;
    }

    /* Extension must by ".mp3" */
    if(strcmp(&filePathName[len - 4], ".mp3") != 0)
    {
        return -1;
    }

    /* Get file name from path */
    char* slash = &filePathName[len - 1];
    while(*slash != '/' && filePathName < slash)
    {
        --slash;
    }

    if(*slash != '/' || filePathName >= slash)
    {
        return -1;
    }

    /* All chars must be digits */
    char* nameBegin = ++slash;
    char* nameEnd = &filePathName[len - 4];
    char* tmp = nameBegin;
    while(tmp < nameEnd)
    {
        if(isdigit(*tmp) == 0)
        {
            return -1;
        }

        ++tmp;
    }

    /* Temp buffer for conversion to int */
    char buffer[16] = {0};
    memcpy(buffer, nameBegin, (size_t) (nameEnd - nameBegin));

    return atoi(buffer);
}

int WriteMp3FragmentsToFile(struct MP3FragmentNode** list, const char* resultFileName)
{
    FILE* file;
    size_t result;

    file = fopen(resultFileName,"wb");

    if(file == NULL)
    {
        return ERROR_RESULT;
    }

    while(1)
    {
        struct MP3FragmentData* data;
        data = ListPopFront(list);

        if(data == NULL)
        {
            break;
        }

        result = fwrite(data->fileData, sizeof(unsigned char), data->fileSize, file);

        if(result != data->fileSize)
        {
            fclose(file);
            ListFreeData(&data);
            return ERROR_RESULT;
        }

        ListFreeData(&data);
    }

    fclose(file);

    return SUCCESS_RESULT;
}
