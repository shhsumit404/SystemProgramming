#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h> /* waitpid */
#include <sys/stat.h> /* stat */
#include <ctype.h> /* isspace */
#include <fcntl.h>

#include "recipe.h"
#include "command.h"

const char fakefile[] = "fakefile";

Recipe* recipes_read(const char* filename); /* read recipes from the Fakefile */
void recipes_print(Recipe* head); /* output recipes to the screen */
void recipes_free(Recipe* head); /* release all memories */
void recipes_process(Recipe* head); /* parse and run recipes */
int recipe_process(Recipe* head, Recipe* recipe); /* parse and run recipe */
Recipe* recipes_find(Recipe* head, const char* targetName); /* find recipe by target name */
int recipes_run(Recipe* recipe); /* run commands from the stack */
int recipes_run_command(const char* cmd); /* run command */
int recipes_launch(Command* cmd); /* execute command */
int recipes_launch_pipes(Command* cmds, int cmdsNum); /* execute commands with pipes */
int recipes_spawn_process(Command* cmd, int in, int* pipes); /* spawn processes. it is used for pipes. */

char* unescape(char* str);
int isFileExists(const char*);


int main(int argc, char* argv[]) {
    Recipe* head = NULL;
    Recipe* recipe;
    head = recipes_read(fakefile);
    if (argc > 1) {
        recipe = recipes_find(head, argv[1]);
        if (recipe) {
            return recipe_process(head, recipe);
        }
        return 0;
    }

    if (!head) {
        fprintf(stdout, "./fake: empty file!\n");
        return 0;
    }

    recipes_process(head);

    recipes_free(head);

    return 0;
}

Recipe* recipes_read(const char* filename) {
    Recipe* head = NULL, *cur = NULL, *temp;
    char* line = NULL;
    char* token = NULL;
    size_t len = 0;
    ssize_t nread = 0;
    FILE* pFile = fopen(filename, "r");
    if (pFile == NULL) {
        fprintf(stderr, "%s not found!\n", filename);
        return 0;
    }

    while ((nread = getline(&line, &len, pFile)) != -1) {
        if (*line == 0) {
            continue;
        }
        switch (*line) {
            case '\n': /* ignore new lines and comments */
            case '#': break;
            case '\t': { /* next target command */
                cur->commands[cur->cmdCount++] = strndup(line + 1, nread - 2);
                break;
            }
            default: { /* target */
                temp = (Recipe*)malloc(sizeof(Recipe));
                if (head == NULL) {
                    head = temp;
                } else {
                    cur->next = temp;
                }
                cur = temp;
                memset(cur, 0, sizeof(Recipe));
                token = strtok (line, " :\n");
                cur->targetName = strdup(token);
                token = strtok(NULL, " \n");
                while (token != NULL) {
                    if (*token == 0) { /* ignore empty strings*/
                        continue;
                    }
                    cur->prereqs[cur->prereqCount++] = strdup(token);
                    token = strtok(NULL, " \n");
                }
                break;
            }
        }
    }
    fclose(pFile); /* close the file */
    if (line) { /* release memory for the line */
        free(line);
    }

    return head;
}

void recipes_print(Recipe* head) {
    while (head != NULL) {
        printf("%s:", head->targetName);
        for (int j = 0; j < head->prereqCount; j++) {
            printf(" %s", head->prereqs[j]);
        }
        printf("\n");
        for (int j = 0; j < head->cmdCount; j++) {
            printf("%s\n", head->commands[j]);
        }
        head = head->next;
    }
}

void recipes_free(Recipe* head) {
    Recipe* temp;
    int i;
    while (head != NULL) {
        free((void*)head->targetName);
        for (i = 0; i < head->prereqCount; i++) {
            free((void*)head->prereqs[i]);
        }
        for (i = 0; i < head->cmdCount; i++) {
            free((void*)head->commands[i]);
        }
        temp = head;
        head = head->next;
        free(temp);
    }
}

int recipe_process(Recipe* head, Recipe* recipe) {
    int i;
    Recipe* temp;
    int result = 0;
    for (i = 0; i < recipe->prereqCount; i++) { /* iterate over all preqs */
        temp = recipes_find(head, recipe->prereqs[i]);
        if (!temp) {
        /* nothing to do: file exist and target not found */
            result = 1;
            continue;
        }
        result = recipe_process(head, temp);
    }

    if (result == 0 || !isFileExists(recipe->targetName)) {
        if (recipes_run(recipe) < 0) {
            fprintf(stderr, "recipes_run error for the %s\n", recipe->targetName);
            return -1;
        }

        if (recipe->prereqCount == 0) {
            recipe->upToDate = 1;
        }
        return 0;
    }
    return 1;
}

void recipes_process(Recipe* head) {
    Recipe* ptr = head;
    recipe_process(head, ptr);
}

Recipe* recipes_find(Recipe* head, const char* targetName) {
    while (head != NULL) {
        if (strcmp(targetName, head->targetName) == 0) {
            return head;
        }
        head = head->next;
    }
    return NULL;
}

int recipes_run(Recipe* recipe) {
    int i;
    char* temp;
    int status;

    if (recipe->upToDate) {
        return 0;
    }
    for(i = 0; i < recipe->cmdCount; i++) {
        fprintf(stdout, "%s\n", recipe->commands[i]);
        temp = strdup(recipe->commands[i]);
        status = recipes_run_command(temp);
        if (status != 0) {
            free(temp);
            return status;
        }
        free(temp);
    }
    if (recipe->prereqCount == 0) {
        recipe->upToDate = 1;
    }
    return 0;
}

int recipes_parse_command(const char* cmd, Command* cmds) {
    int cmdsNum = 0; /* number of commands */
    int argsNum = 0; /* number of args */
    char* token;
    char* ptr = NULL;
    enum states { IDLE, LITERAL, STRING,
        INPUT, INPUT_FILE, QUOTED_INPUT_FILE,
        OUTPUT, OUTPUT_FILE, QUOTED_OUTPUT_FILE
    } state = IDLE;
    /* parse command by tokens */
    if (!cmd) {
        return 0;
    }

    for (ptr = (char*)cmd; *ptr != '\0'; ptr++) {
        switch (state) {
            case IDLE: {
                if (isspace(*ptr)) { /* skip all spaces */
                    continue;
                }
                if (*ptr == '\"') { /* this is string */
                    state = STRING;
                    token = ptr + 1;
                } else if (*ptr == '>') { /* ouput redirection */
                    state = OUTPUT;
                } else if (*ptr == '<') { /* input redirection */
                    state = INPUT;
                } else if (*ptr == '|') { /* pipe detected */
                    cmdsNum++;
                    argsNum = 0;
                } else {
                    state = LITERAL;
                    token = ptr;
                }
                break;
            }
            case INPUT: {
                if (cmds[cmdsNum].input) {
                    fprintf(stderr, "Duplicated input redirection\n");
                    return -1;
                }
                if (isspace(*ptr)) { /* skip all spaces */
                    continue;
                }
                if (*ptr == '\"') {
                    state = QUOTED_INPUT_FILE;
                    cmds[cmdsNum].input = ptr + 1;
                } else {
                    state = INPUT_FILE;
                    cmds[cmdsNum].input = ptr;
                }
                break;
            }
            case INPUT_FILE: {
                if (isspace(*ptr)) {
                    state = IDLE;
                    *ptr = 0;
                }
                break;
            }
            case QUOTED_INPUT_FILE: {
                if (*ptr == '\"') {
                    state = IDLE;
                    *ptr = 0;
                }
                break;
            }
            case OUTPUT: {
                if (cmds[cmdsNum].output) {
                    fprintf(stderr, "Duplicated output redirection\n");
                    return -1;
                }
                if (isspace(*ptr)) { /* skip all spaces */
                    continue;
                }
                if (*ptr == '\"') {
                    state = QUOTED_OUTPUT_FILE;
                    cmds[cmdsNum].output = ptr + 1;
                } else {
                    state = OUTPUT_FILE;
                    cmds[cmdsNum].output = ptr;
                }
                break;
            }
            case OUTPUT_FILE: {
                if (isspace(*ptr)) {
                    state = IDLE;
                    *ptr = 0;
                }
                break;
            }
            case QUOTED_OUTPUT_FILE: {
                if (*ptr == '\"') {
                    state = IDLE;
                    *ptr = 0;
                }
                break;
            }
            case STRING: {
                if (*ptr == '\"') { /* this is string */
                    *ptr = 0;
                    cmds[cmdsNum].args[argsNum++] = unescape(token);
                    state = IDLE;
                }
                break;
            }
            case LITERAL: {
                if (isspace(*ptr)) { /* this is end of literal */
                    *ptr = 0;
                    cmds[cmdsNum].args[argsNum++] = token;
                    state = IDLE;
                }
                break;
            }
        }
    }

    if (state == STRING) {
        fprintf(stderr, "Truncated string: expected quote\n");
        return -1;
    }
    if (state == LITERAL) {
        cmds[cmdsNum].args[argsNum++] = token;
    }

    return cmdsNum + 1;
}

int recipes_run_command(const char* cmd) {
    Command cmds[MAX_CMDS_COUNT]; /* array of commands */
    int cmdsNum = 0; /* number of commands */
    /* parse command by tokens */
    memset(cmds, 0, MAX_CMDS_COUNT * sizeof(Command)); /* setup cmds to zero */
    cmdsNum = recipes_parse_command(cmd, cmds);
    if (cmdsNum < 0) {
        fprintf(stderr, "recipes_parse_command error\n");
        return -1;
    } else if (cmdsNum == 0) {
        return 0;
    }

    if (cmdsNum == 1) {
        return recipes_launch(cmds);
    } else {
        return recipes_launch_pipes(cmds, cmdsNum);
    }
}

int recipes_launch(Command* cmd) {
    pid_t pid;
    int status, fd;

    pid = fork();
    if (pid == 0) { /* child */
        /* check output redirection */
		if (cmd->output) {
			/* open or create a file */
			fd = open(cmd->output, O_CREAT | O_TRUNC | O_WRONLY, 0600);
			/* replace standard output by with file */
			dup2(fd, STDOUT_FILENO);
			close(fd);
		}
        /* check input redirection */
        if (cmd->input) {
			/* open file for read only */
			fd = open(cmd->input, O_RDONLY, 0600);
			/* replace standard input by with file */
			dup2(fd, STDIN_FILENO);
			close(fd);
		}
        /* execute the command */
        if (execvp(cmd->args[0], cmd->args) == -1) {
            fprintf(stderr, "recipes_launch: execvp error\n");
        }
        exit(EXIT_FAILURE);
    } else if (pid < 0) {
        fprintf(stderr, "recipes_launch: fork error\n");
    } else {/* parent */
        do { /* waiting child */
            waitpid(pid, &status, WUNTRACED);
        } while (!WIFEXITED(status) && !WIFSIGNALED(status));
        return status;
    }

  return 0;
}


int recipes_launch_pipes(Command* cmds, int cmdsNum) {
    int i;
    int in, fd [2];
    pid_t pid;
    int status;

    in = 0; /* the first process get input from stdin */
    for (i = 0; i < cmdsNum - 1; i++) {
        if (pipe(fd) == -1) { /* create the pipe */
            fprintf(stderr, "pipe error\n");
            return -1;
        }

        if (recipes_spawn_process(cmds + i, in, fd) < 0) {
            fprintf(stderr, "recipes_spawn_process error\n");
            return -1;
        }
        close(fd[1]);

        /* keep the read end of the pipe for the next child */
        in = fd[0];
    }
    if ((pid = fork ()) == 0) { /* child */
        /* Last command */
        if (in != 0) {
            dup2(in, 0);
            close(in);
        }
        if (execvp(cmds[i].args[0], cmds[i].args) < 0) {
            fprintf(stderr, "execvp error\n");
        }
        exit(EXIT_FAILURE);
    }
    else if (pid < 0) {/* error */
        fprintf(stderr, "fork error\n");
    } else { /* parent */
        close(in);
         do { /* waiting child */
           // wait(&status);
            waitpid(pid, &status, WUNTRACED);
        } while (!WIFEXITED(status));
        do { /* waiting child */
            //wait(&status);
        } while (wait(&status) > 0);
        return status;
    }
    return 0;
}

int recipes_spawn_process(Command* cmd, int in, int* pipes) {
    pid_t pid;

    if ((pid = fork ()) == 0) { /* child */
        if (in != 0) { /* not stdin */
            dup2(in, 0); /* replace stdin by in */
            close(in); /* close descriptor */
        } else {
            close(pipes[0]);
        }

        if (pipes[1] != 1) { /* not a stdout */
            dup2(pipes[1], 1); /* replace stdout by out */
            close(pipes[1]);
        }
        return execvp(cmd->args[0], cmd->args);
    }
    else if (pid < 0) {
        perror("spawn");
    }
    return pid;
}

char* unescape(char* str) {
    char* result = str, *ptr = str;
    while (*str != 0) {
        if (*str == '\\' && *(str + 1) == '\\') {
            str++;
        }
        *ptr++ = *str++;
    }
    *ptr = 0;
    return result;
}

int isFileExists(const char* filename) {
    return access(filename, F_OK) == 0 ? 1 : 0;
}
