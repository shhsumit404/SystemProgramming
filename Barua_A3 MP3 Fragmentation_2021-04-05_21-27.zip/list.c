/*the file "list.c" contains functions used to work with a singly linked list */
#include <stdlib.h>

/* __STDC_WANT_LIB_EXT2__ for strdup  */
/* Source: https://stackoverflow.com/questions/46013382/c-strndup-implicit-declaration */
#define __STDC_WANT_LIB_EXT2__ 1
#include <string.h>
#include "list.h"

void ListInit(struct MP3FragmentNode **head)
{
    *head = NULL;
}

int ListIsEmpty(struct MP3FragmentNode* head)
{
    return head == NULL ? 1 : 0;
}

int ListInsertToFront2(struct MP3FragmentNode** head, struct MP3FragmentData* data)
{
    struct MP3FragmentNode* newNode;
    newNode = (struct MP3FragmentNode*) malloc(sizeof(struct MP3FragmentNode));

    if(newNode == NULL)
    {
        return ERROR_RESULT;
    }

    newNode->data = data;
    newNode->next = *head;
    *head = newNode;

    return SUCCESS_RESULT;
}

int ListInsertToFront(struct MP3FragmentNode** head, const char* filePathName)
{
    struct MP3FragmentData* newData;
    newData = (struct MP3FragmentData*) malloc(sizeof(struct MP3FragmentData));

    if(newData == NULL)
    {
        return ERROR_RESULT;
    }

    newData->filePathName = strdup(filePathName);
    newData->id = -1;
    newData->fileSize = 0;
    newData->fileData = NULL;

    return ListInsertToFront2(head, newData);
}

struct MP3FragmentData* ListPopFront(struct MP3FragmentNode** head)
{
    if(*head == NULL)
    {
        return NULL;
    }
    else
    {
        struct MP3FragmentData* result;
        struct MP3FragmentNode* current;

        result = (*head)->data;
        current = *head;
        *head = (*head)->next;

        free(current);

        return result;
    }
}

int ListInsertOrdered(struct MP3FragmentNode** head, struct MP3FragmentData* data)
{
    struct MP3FragmentNode* prev;
    struct MP3FragmentNode* current;
    struct MP3FragmentNode* newNode;

    if(*head == NULL)
    {
        return ListInsertToFront2(head, data);
    }

    if((*head)->data->id >= data->id)
    {
        return ListInsertToFront2(head, data);
    }

    prev = NULL;
    current = *head;

    while(current->next != NULL && current->data->id < data->id)
    {
        prev = current;
        current = current->next;
    }

    if(prev == NULL && current->data->id >= data->id)
    {
        return ListInsertToFront2(head, data);
    }

    newNode = (struct MP3FragmentNode*) malloc(sizeof(struct MP3FragmentNode));

    if(newNode == NULL)
    {
        return ERROR_RESULT;
    }

    newNode->data = data;

    if(prev == NULL)
    {
        newNode->next = current->next;
        current->next = newNode;
    }
    else
    {
        if(current->data->id >= data->id)
        {
            newNode->next = current;
            prev->next = newNode;
        }
        else
        {
            newNode->next = current->next;
            current->next = newNode;
        }
    }

    return SUCCESS_RESULT;
}

void ListFree(struct MP3FragmentNode **head)
{
    struct MP3FragmentNode* current;
    current = *head;

    while(current)
    {
        struct MP3FragmentNode* temp;
        temp = current;

        current = current->next;

        ListFreeData(&temp->data);
        free(temp);
    }

    *head = NULL;
}

void ListFreeData(struct MP3FragmentData** data)
{
    free((*data)->filePathName);
    free((*data)->fileData);
    free(*data);
    *data = NULL;
}
