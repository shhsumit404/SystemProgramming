#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "card.h"

/* Define names for output files */
#define INDEX_FILENAME "index.bin"
#define CARDS_FILENAME "cards.bin"

const char* rarity_names[4] = {"common", "uncommon", "rare", "mythic"};

/* structure for card names and offset */
struct card_index
{
    char *name;         /* card name */
    long int offset;    /* card offset at the cards file */
};

/* structure for all card names and offsets */
struct card_index_array
{
    struct card_index *items;
    int size;
    int capacity;
};

/* Initializes array for storing 10 card indexes */
void initialize_index_array(struct card_index_array *cards);


/* Deletes all cards from the array, frees all allocated memory */
void clear_index_array(struct card_index_array* cards);

/* Add new card into array
   If array is full, increases capacity by 10. */
void add_index_to_array(struct card_index_array* cards, struct card_index* index);

/* Function reads index binary file and fills cards index array */
void load_index_file(struct card_index_array* cards, FILE* fpindex);

/* Creates copy of the given string and returns pointer to the copy */
char* copy_str(const char* str);

/* Function for comparing card indexes by name field */
int compare_card_index (const struct card_index* card1, const struct card_index* card2);

/* Allocates memory for all strings at the card to given maximum size */
void initialize_card(struct card* pcard, int str_size);

/* Function reads card fields at given offset from the given binary card file */
void read_card_at_offset(struct card* pcard, FILE* fpcards, long int offset);

/* Prints the given card into the screen */
void print_card(struct card* pcard);

/* Frees all string fields of the given card */
void clear_card(struct card* pcard);

int main()
{
    FILE* fpindex;
    FILE* fpcards;
    struct card_index_array cards;
    struct card card_buffer;
    struct card_index *pindex = NULL;
    struct card_index index;

    /* try to open source index file */
    fpindex = fopen(INDEX_FILENAME, "rb");
    if (!fpindex) {
        fprintf(stderr, "./search: cannot open(\"%s\"): No such file or directory\n", INDEX_FILENAME);
        return 1;
    }

    /* try to open source cards file */
    fpcards = fopen(CARDS_FILENAME, "rb");
    if (!fpcards) {
        fprintf(stderr, "./search: cannot open(\"%s\"): No such file or directory\n", CARDS_FILENAME);
        fclose(fpindex);
        return 1;
    }

    // initialize buffer for card index
    index.name = (char*)malloc(50);
    index.offset = 0;

    // initialize arrays
    initialize_index_array(&cards);

    load_index_file(&cards, fpindex);

    /* close index file */
    fclose(fpindex);

    /* initialize card buffer */
    initialize_card(&card_buffer, 1024);

    /* Read card name until 'q' entered */
    printf(">> ");
    strcpy(index.name,"");
    scanf("%[^\n]%*c", index.name);
    printf("%s\n", index.name);
    while (strcmp(index.name, "q") != 0 && strcmp(index.name, "") != 0) {

        /* looking for the given name */
        pindex = bsearch(&index, cards.items, cards.size, sizeof(struct card_index), (int(*) (const void *, const void *)) compare_card_index);
        if (pindex != NULL) {
            /* fill card buffer name */
            strcpy(card_buffer.name, pindex->name);
            /* fill the rest card buffer fields */
            read_card_at_offset(&card_buffer, fpcards, pindex->offset);

            /* print card to the screen */
            print_card(&card_buffer);
            printf("\n");
        }
        else {
            printf("./search: '%s' not found!\n", index.name);
        }
        printf(">> ");
        strcpy(index.name,"");
        scanf("%[^\n]%*c", index.name);
        printf("%s\n", index.name);
    }

    /* Free allocated memory */
    free(index.name);
    clear_card(&card_buffer);
    clear_index_array(&cards);

    /* close cards file */
    fclose(fpcards);

    return 0;
}

/* Initializes array for storing 10 card indexes */
void initialize_index_array(struct card_index_array *cards)
{
    if (cards == NULL) {
        return ;
    }

    cards->items = (struct card_index*) malloc (sizeof(struct card_index) * 10);
    cards->size = 0;
    cards->capacity = 10;
}

/* Deletes all cards from the array, frees all allocated memory */
void clear_index_array(struct card_index_array* cards)
{
    int i;

    if (cards == NULL) {
        return ;
    }

    for (i = 0; i < cards->size; i++) {
        free(cards->items[i].name);
    }
    free(cards->items);
    cards->items = NULL;
    cards->capacity = 0;
    cards->size = 0;
}

/* Add new card into array
   If array is full, increases capacity by 10. */
void add_index_to_array(struct card_index_array* cards, struct card_index* index)
{
    if (cards == NULL || index == NULL) {
        return;
    }

    struct card_index* old_items;

    /* If array is full */
    if (cards->size == cards->capacity) {
        /* increase array capacity by 10 */
        old_items = cards->items;
        cards->capacity += 10;
        cards->items = (struct card_index*) malloc (sizeof(struct card_index) * cards->capacity);
        memcpy(cards->items, old_items, sizeof(struct card_index) * cards->size);
        free(old_items);
    }

    /* Copy new index at the end of the array */
    cards->items[cards->size].name = copy_str(index->name);
    cards->items[cards->size].offset = index->offset;
    cards->size++;
}

/* Creates copy of the given string and returns pointer to the copy */
char* copy_str(const char* str)
{
    int size;
    char* new_str;

    if (str == NULL) {
        return NULL;
    }

    /* allocate memory for copy string */
    size = strlen(str);

    /* copy all characters including the last \0 */
    new_str = (char*) malloc (sizeof(char) * (size + 1));
    memcpy(new_str, str, size + 1);

    /* return pointer to the string copy */
    return new_str;
}

/* Function reads index binary file and fills cards index array */
void load_index_file(struct card_index_array* cards, FILE* fpindex)
{
    uint32_t strSize;
    struct card_index index_buffer;

    while (fread(&strSize, sizeof(strSize), 1, fpindex) && !feof(fpindex))
    {
        /* allocate memory for name */
        index_buffer.name = (char*)malloc(strSize + 1);
        memset(index_buffer.name, 0, strSize + 1);
        /* read name */
        fread(index_buffer.name, sizeof(char), strSize, fpindex);
        /* read offset */
        fread(&index_buffer.offset, sizeof(index_buffer.offset), 1, fpindex);

        /* copy index into array */
        add_index_to_array(cards, &index_buffer);

        free(index_buffer.name);
    }
}

/* Function for comparing card indexes by name field */
int compare_card_index (const struct card_index* card1, const struct card_index* card2)
{
    return strcmp(card1->name, card2->name);
}

/* Allocates memory for all strings at the card to given maximum size */
void initialize_card(struct card* pcard, int str_size)
{
    if (pcard == NULL) {
        return ;
    }

    pcard->id = 0;
    pcard->rarity = common;
    pcard->converted_cost = 0;
    pcard->name = (char*) malloc (str_size);
    pcard->cost = (char*) malloc (str_size);
    pcard->type = (char*) malloc (str_size);
    pcard->text = (char*) malloc (str_size);
    pcard->stats = (char*) malloc (str_size);
}


/* Function reads string from given binary file in format <length><chars without ending\0>
   and copies at given field pstr
   str should be previously allocated for enough memory */
void read_string(FILE* fp, char* str)
{
    uint32_t strSize;

    if (fp == NULL || str == NULL) {
        return ;
    }

    /* read string length */
    fread(&strSize, sizeof(strSize), 1, fp);
    fread(str, 1, strSize, fp);
    str[strSize] = 0;
}

/* Function reads card fields at given offset from the given binary card file */
void read_card_at_offset(struct card* pcard, FILE* fpcards, long int offset)
{
    if (pcard == NULL || fpcards == NULL) {
        return ;
    }

    /* set file pointer at given offset */
    fseek(fpcards, offset, SEEK_SET);

    /* read card fields except name into card structure */
    fread(&(pcard->id), sizeof(pcard->id), 1, fpcards);
    read_string(fpcards, pcard->cost);
    fread(&(pcard->converted_cost), sizeof(pcard->converted_cost), 1, fpcards);
    read_string(fpcards, pcard->type);
    read_string(fpcards, pcard->text);
    read_string(fpcards, pcard->stats);
    fread(&(pcard->rarity), sizeof(pcard->rarity), 1, fpcards);
}

/* Prints the given card into the screen */
void print_card(struct card* pcard)
{
    if (pcard == NULL) {
        return;
    }

    printf("%-32s%20s\n", pcard->name, pcard->cost);
    printf("%-44s%8s\n", pcard->type, rarity_names[pcard->rarity]);
    printf("----------------------------------------------------\n");
    printf("%s\n", pcard->text);
    printf("----------------------------------------------------\n");
    printf("%52s\n", pcard->stats);
}

/* Frees all string fields of the given card */
void clear_card(struct card* pcard)
{
    if (pcard == NULL) {
        return;
    }
    free(pcard->name);
    free(pcard->cost);
    free(pcard->type);
    free(pcard->text);
    free(pcard->stats);
}
