#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

// data structure for storing offset in the file
struct offset {
    int id;
    int offset;
};

// data structure for storing depts names and total sales
struct  department {
    char dept_name[64];
    float total_sales;
};

int comp(const struct offset *a, const struct offset *b) {
    return a->id - b->id;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <.csv_file>\n", argv[0]);
        return 0;
    }

    // index arrays for data structures: max_size is for easier change, _size represents current size
    int off_size = 0;
    int off_max_size = 1000000;
    struct offset *offsets = malloc(off_max_size * sizeof(struct offset));

    int depts_size = 0;
    int depts_max_size = 1000000;
    struct department *depts = malloc(depts_max_size * sizeof(struct department));

    // pointer to file with csv data
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("File not found!\n");
        return 0;
    }

    // store current offset in the file, for adding into offsets array
    // offset is number of bytes from beginning of the file
    int cur_offset = 0;
    while (!feof(file)) {
        size_t line_size;
        char *line = NULL;
        int read = getline(&line, &line_size, file);
        if (read != -1) {
            // tokenize string by commas to get values
            char *tok = strtok(line, ",");
            int id = atoi(tok);

            tok = strtok(NULL, ",");
            char dept[64];
            strcpy(dept, tok); // save department to another array, as tok is rewritten

            tok = strtok(NULL, ",");
            float amount = atof(tok + 1); // ignore $ sign

            // save offset data in the array
            offsets[off_size].id = id;
            offsets[off_size++].offset = cur_offset;
            // add length of current line to offset
            cur_offset += read;

            // linear search in departments, to add amount to existing dept
            int dept_exists = 0;
            for (int i = 0; i < depts_size; i++) {
                if (strcmp(depts[i].dept_name, dept) == 0) {
                    dept_exists = 1;
                    depts[i].total_sales += amount;
                }
            }
            // if dept with given name does not exist, create a new one
            if (!dept_exists) {
                strcpy(depts[depts_size].dept_name, dept);
                depts[depts_size++].total_sales = amount;
            }

            free(line);
        }
    }

    // sort offsets by id, to enable bineary search in it
    qsort(offsets, off_size, sizeof(struct offset), (int(*) (const void *, const void *))comp);

    while (!feof(stdin)) {
        printf("> ");
        char input[64];
        scanf("%s", input);
        // additional break (in case of piping last string is read twice)
        // if (feof(stdin)) break;

        if (!isatty(STDIN_FILENO)) { // check if input is piped
            printf("%s\n", input);
        }
        //printf("\n");

        // check digit
        if (input[0] >= '0' && input[0] <= '9') {
            int id = atoi(input);
            // binary search in ids
            // offsets[r].id is always bigger than needed id,
            // offsets[l].id is less or equal, but closest to id in the end
            int l = 0, r = off_size;
            while (r - l > 1) {
                int m = (l + r) / 2;
                if (offsets[m].id > id) r = m;
                else l = m;
            }
            // if l is not equal, there is no searched id in array
            if (offsets[l].id != id) {
                printf("Transaction id not found!\n");
            }
            else {
                // found needed id, move file cursor to offset position
                fseek(file, offsets[l].offset, SEEK_SET);
                size_t line_size;
                char *line = NULL;
                // read line and tokenize it by ','
                getline(&line, &line_size, file);

                char *tok = strtok(line, ",");
                printf("\nid: %s\n", tok);

                tok = strtok(NULL, ",");
                printf("dept: %s\n", tok);

                tok = strtok(NULL, ",");
                printf("amount: %s\n", tok);

                tok = strtok(NULL, ",");
                printf("card #: %s\n", tok);

                tok = strtok(NULL, ",");
                printf("type: %s", tok);
            }
        }
        else {
            // input is not digit, find department
            int contains = 0;
            for (int i = 0; i < depts_size; i++) {
                if (strcmp(input, depts[i].dept_name) == 0) {
                    contains = 1;
                    printf("\ndept: %s\n", depts[i].dept_name);
                    printf("total: $%.2f\n", depts[i].total_sales);
                }
            }
            if (!contains) {
                printf("Department name not found!\n");
            }
        }
        printf("\n");

    }

    fclose(file);
//printf("\n");
printf("> \n");
    free(offsets);
    free(depts);
}
